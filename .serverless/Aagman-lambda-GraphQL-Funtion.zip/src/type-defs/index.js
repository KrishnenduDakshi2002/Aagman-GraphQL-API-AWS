"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.typeDefs = void 0;
exports.typeDefs = `#graphql
  type Query {
    hello: String
    test: String
  },
  type Mutation{
    mutateHello: String
  }
`;
