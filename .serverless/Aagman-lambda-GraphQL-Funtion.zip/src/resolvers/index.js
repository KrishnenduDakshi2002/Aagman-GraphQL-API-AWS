"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolvers = void 0;
exports.resolvers = {
    Query: {
        hello: () => "hello world",
        test: () => "this is test"
    },
    Mutation: {
        mutateHello: () => 'this is mutated hello'
    }
};
